package com.triply.barrierfreetrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarrierFreeTripApplicationTests {

	@Test
	void contextLoads() {
	}

}
