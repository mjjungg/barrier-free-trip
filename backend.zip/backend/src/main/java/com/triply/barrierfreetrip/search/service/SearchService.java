package com.triply.barrierfreetrip.search.service;

import com.triply.barrierfreetrip.search.SearchDto;

public interface SearchService {
    public SearchDto search(String keyword);
}
