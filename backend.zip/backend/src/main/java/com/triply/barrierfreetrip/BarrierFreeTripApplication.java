package com.triply.barrierfreetrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarrierFreeTripApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarrierFreeTripApplication.class, args);
	}

}
