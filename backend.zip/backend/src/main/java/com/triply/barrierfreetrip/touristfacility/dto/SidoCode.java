package com.triply.barrierfreetrip.touristfacility.dto;

import lombok.Data;

@Data
public class SidoCode {
    private String areaCode;
    private String cdNm;
}
