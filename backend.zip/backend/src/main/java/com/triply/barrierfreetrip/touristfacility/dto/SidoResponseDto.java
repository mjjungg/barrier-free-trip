package com.triply.barrierfreetrip.touristfacility.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SidoResponseDto {
    private String code;
    private String name;
}
