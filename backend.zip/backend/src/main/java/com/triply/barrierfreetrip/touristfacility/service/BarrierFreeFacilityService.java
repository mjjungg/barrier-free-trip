package com.triply.barrierfreetrip.touristfacility.service;

import com.triply.barrierfreetrip.touristfacility.domain.BarrierFreeFacility;

import java.util.List;

public interface BarrierFreeFacilityService {
    public BarrierFreeFacility findByContentId(String contentId);
}
