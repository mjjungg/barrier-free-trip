package com.triply.barrierfreetrip.member.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class SocialMemberDto {
    private String email;
    private String nickname;

}
